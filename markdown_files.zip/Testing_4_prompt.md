**Complete Testing Protocol for AccessEd Fixes**

**Gemini CLI Test Script - All 6 Issues**

Date: February 27, 2026  
Execution Time: 10-15 minutes  
Test Environment: Windows PowerShell + Browser Console

**Prerequisites**

Before running tests, ensure:

- Server is running (npm run dev in backend)
- Frontend is running (npm run dev in client)
- You're logged in as a Teacher user with access to Software Engineering course
- PowerShell terminal open in project root directory

**Test Suite 1: File Upload & Conversion Pipeline**

**Tests Issues: 1, 2, 3**  
**Estimated Time: 5 minutes**

**Step 1.1: Prepare Test File**

Create a simple test file:

**Create test file with known content**

"Python is a high-level programming language. It emphasizes code readability with significant indentation." | Out-File -FilePath "test-content.txt" -Encoding utf8

**Verify file was created**

Get-Content "test-content.txt"

**Expected Output**: Should display the test text.

**Step 1.2: Upload File via UI**

**Manual Action Required:**

1.  Navigate to: http://localhost:5000/teacher/courses/\[software-engineering-id\]/content
2.  Click "Upload Content" button
3.  Select test-content.txt
4.  Title: "Automated Test Upload"
5.  Click "Upload" and wait for success message

**Expected**: "Content uploaded successfully" toast appears within 5 seconds.

**Step 1.3: Verify Database Record**

Run this query immediately after upload:

**Connect to database and query**

**Replace with your database connection command**

**For SQLite:**

**sqlite3 dev.db "SELECT id, title, course_offering_id, transcript_status, simplified_status, audio_status, created_at FROM content_items ORDER BY created_at DESC LIMIT 1;"**

**For PostgreSQL via psql:**

**psql -U postgres -d accesseducation -c "SELECT id, title, course_offering_id, transcript_status, simplified_status, audio_status, created_at FROM content_items ORDER BY created_at DESC LIMIT 1;"**

**Paste this exact query for Gemini to run:**

Run this database query and paste the full output:

SELECT  
id,  
title,  
course_offering_id,  
transcript_status,  
simplified_status,  
audio_status,  
created_at  
FROM content_items  
ORDER BY created_at DESC  
LIMIT 1;

**Expected Output**:

- title: "Automated Test Upload"
- course_offering_id: NOT NULL (should show actual UUID)
- transcript_status: "COMPLETED" or "PENDING" (within 10 seconds should be COMPLETED)
- simplified_status: "COMPLETED" or "READYFORREVIEW"
- audio_status: "COMPLETED"

**✅ PASS Criteria**: course_offering_id is NOT NULL  
**❌ FAIL if**: course_offering_id is NULL → Issue 1 not fixed

**Step 1.4: Verify Physical File Creation**

Wait 15 seconds after upload for conversion to complete, then check filesystem:

**Get the content ID from previous query (replace with actual ID)**

$contentId = "PASTE_ID_FROM_QUERY_HERE"

**Check if converted folder exists**

Test-Path "uploads\\converted$contentId"

**List all files in converted folder**

Get-ChildItem "uploads\\converted$contentId" -Recurse | Select-Object Name, Length, LastWriteTime

**Expected Output**:  
True

Name Length LastWriteTime

transcript.txt XXX 2026-02-27 11:45:XX  
simplified.txt XXX 2026-02-27 11:45:XX  
audio.txt XXX 2026-02-27 11:45:XX

**✅ PASS Criteria**: All three files exist with non-zero length  
**❌ FAIL if**: Folder doesn't exist OR files are missing → Issue 2 not fixed

**Step 1.5: Verify File Content**

**Check transcript content**

Write-Host "\`n=== TRANSCRIPT.TXT ===" -ForegroundColor Cyan  
Get-Content "uploads\\converted$contentId\\transcript.txt"

Write-Host "\`n=== SIMPLIFIED.TXT ===" -ForegroundColor Cyan  
Get-Content "uploads\\converted$contentId\\simplified.txt"

Write-Host "\`n=== AUDIO.TXT ===" -ForegroundColor Cyan  
Get-Content "uploads\\converted$contentId\\audio.txt"

**Expected**: Each file contains readable text (should be similar to original content).

**✅ PASS Criteria**: All files contain actual text content (not empty or "null")  
**❌ FAIL if**: Files are empty or contain error messages

**Step 1.6: Test Dashboard Visibility**

**Manual Action Required:**

1.  Navigate to: http://localhost:5000/student/dashboard
2.  Scroll to "New Content" section
3.  Look for "Automated Test Upload"

**Expected**: File appears in "New Content" list within 5 seconds of page load.

**✅ PASS Criteria**: File appears in dashboard  
**❌ FAIL if**: File doesn't appear → Issue 1 not fully fixed (frontend query issue)

**Test Suite 2: Content Viewer Format Loading**

**Tests Issues: 3**  
**Estimated Time: 3 minutes**

**Step 2.1: Open Content Viewer**

**Manual Action Required:**

1.  From dashboard, click on "Automated Test Upload"
2.  Open browser DevTools (F12)
3.  Go to Console tab
4.  Clear console (Ctrl+L)

**Step 2.2: Test Original Format**

**Expected**: Content loads showing the original text.

**Check Console**:

Should see: GET /api/content/\[id\] → 200 OK  
Should NOT see: 404 errors

**✅ PASS Criteria**: Content displays, no 404 errors  
**❌ FAIL if**: Blank page or 404 in console

**Step 2.3: Test Transcript Format**

**Manual Action Required:**

1.  Click "Transcript" button in format selector
2.  Watch console for network requests

**Expected Console Output**:  
GET /api/content/\[id\]/format-url?format=transcript → 200 OK  
GET /api/content/file/uploads/converted/\[id\]/transcript.txt → 200 OK

**Expected UI**: Transcript text displays in viewer.

**✅ PASS Criteria**: Transcript loads without errors  
**❌ FAIL if**: 404 error on transcript.txt → Issue 3 not fixed

**Step 2.4: Test Simplified Format**

**Manual Action Required:**

1.  Click "Simplified" button
2.  Watch console

**Expected**:

- 200 OK on format-url API
- 200 OK on simplified.txt file
- Simplified text displays

**✅ PASS Criteria**: Simplified format loads  
**❌ FAIL if**: 404 error

**Step 2.5: Test Audio Format**

**Manual Action Required:**

1.  Click "Audio" button
2.  Watch console
3.  Observe if audio player appears

**Expected Console**:  
GET /api/content/\[id\]/format-url?format=audio → 200 OK  
GET /api/content/file/uploads/converted/\[id\]/audio.txt → 200 OK

**Expected UI**: Audio player controls appear (see Issue 4 test for details).

**✅ PASS Criteria**: Audio format loads without 404  
**❌ FAIL if**: 404 error or "Format unavailable" message

**Test Suite 3: Audio Player Controls**

**Tests Issue: 4**  
**Estimated Time: 3 minutes**

**Step 3.1: Basic Playback**

**Manual Action Required** (with Audio format selected):

1.  Locate audio player at bottom of page
2.  Check for these UI elements:
    - Play/Pause button (center)
    - Skip back 10s button (left)
    - Skip forward 10s button (right)
    - Time display (e.g., "0:05 / 0:30")
    - Playback speed selector (right side)
    - Progress bar (top of player)

**✅ PASS Criteria**: All elements visible  
**❌ FAIL if**: Only basic play/pause button → Issue 4 not implemented

**Step 3.2: Play/Pause Functionality**

**Manual Action Required:**

1.  Click Play button (▶)
2.  Wait 3 seconds
3.  Click Pause button (⏸)

**Expected Behavior**:

- Voice synthesis starts speaking the text
- Button icon changes from Play to Pause
- Time counter increases (e.g., "0:03 / 0:30")
- Progress bar fills gradually

**✅ PASS Criteria**: All behaviors work  
**❌ FAIL if**: Time doesn't update OR progress bar doesn't move

**Step 3.3: Skip Controls**

**Manual Action Required:**

1.  Click Play
2.  Wait until time shows 0:05 or more
3.  Click "Skip back 10s" button (⏮)
4.  Observe time counter

**Expected**: Time decreases by ~10 seconds (or to 0:00 if less than 10s in).

**Then test forward**:

1.  Click "Skip forward 10s" button (⏭)
2.  Observe time counter

**Expected**: Time increases by ~10 seconds.

**✅ PASS Criteria**: Both skip buttons change time counter  
**❌ FAIL if**: Buttons do nothing OR cause errors

**Step 3.4: Playback Speed**

**Manual Action Required:**

1.  Click Play
2.  Select "1.5x" from speed dropdown
3.  Listen to speech

**Expected**: Speech becomes noticeably faster.

**Then test**:

1.  Select "0.75x"

**Expected**: Speech becomes slower.

**✅ PASS Criteria**: Speed changes affect speech rate  
**❌ FAIL if**: No change in speech speed

**Step 3.5: Progress Bar Scrubbing**

**Manual Action Required:**

1.  Click Play, let it run to ~0:10
2.  Click/drag progress bar to middle position
3.  Observe time counter and speech

**Expected**:

- Time jumps to new position
- Speech restarts from that point (approximate)

**Note**: Due to browser TTS limitations, seeking is approximate.

**✅ PASS Criteria**: Time changes when scrubbing  
**❌ FAIL if**: Scrubbing does nothing

**Test Suite 4: Progress Bar & Font Slider**

**Tests Issues: 5, 6**  
**Estimated Time: 2 minutes**

**Step 4.1: Reading Progress Bar**

**Manual Action Required:**

1.  Switch to "Transcript" or "Simplified" format (text-based)
2.  Locate progress indicator in footer (bottom-right area)
3.  Note initial progress (should be 0% at top of page)
4.  Scroll down slowly to bottom of content
5.  Watch progress bar fill

**Expected Behavior**:

- Progress starts at 0%
- Increases smoothly as you scroll
- Reaches 100% when at page bottom
- Bar stays within container (doesn't overflow)

**✅ PASS Criteria**:

- Progress goes from 0% to 100%
- Bar never exceeds container width
- Percentage text matches visual bar

**❌ FAIL if**:

- Progress shows 100% at top → Issue 5 not fixed
- Bar overflows container → CSS not fixed
- Progress exceeds 100% (e.g., "127%") → Math.min() not applied

**Step 4.2: Font Size Slider**

**Manual Action Required:**

1.  Locate font size slider in footer (usually has "A" icon)
2.  Note current text size visually
3.  Drag slider to the right (increase size)
4.  Observe if text becomes larger

**Expected**: Text visibly increases in size immediately.

**Then test**:

1.  Drag slider to the left (decrease size)

**Expected**: Text becomes smaller.

**Check Percentage Display**:

- Slider should show percentage (e.g., "100%", "125%", "87.5%")
- Percentage should update as you drag

**✅ PASS Criteria**:

- Text size changes in real-time as slider moves
- Percentage display updates during drag
- Works with mouse AND keyboard (arrow keys when focused)

**❌ FAIL if**:

- Slider moves but text size doesn't change → State binding broken (Issue 6)
- Percentage display doesn't update → onChange not firing
- Text changes only after releasing slider → Should be real-time

**Step 4.3: Combined Progress + Font Test**

**Manual Action Required:**

1.  Set font size to largest (150%)
2.  Scroll to middle of document
3.  Check progress bar still works correctly

**Expected**: Progress bar calculations still accurate even with larger text (document height recalculated).

**✅ PASS Criteria**: Progress still reflects scroll position accurately  
**❌ FAIL if**: Progress becomes inaccurate with different font sizes

**Test Suite 5: Edge Cases & Error Handling**

**Optional: Advanced Testing**  
**Estimated Time: 3 minutes**

**Step 5.1: Upload Without Course Context**

**Manual Action Required:**

1.  Navigate directly to upload page without course context
2.  Try uploading a file

**Expected**: Either:

- Upload form requires course selection dropdown, OR
- Error message: "Please select a course before uploading"

**✅ PASS Criteria**: System prevents orphaned uploads  
**❌ FAIL if**: Upload succeeds but content has NULL course_offering_id

**Step 5.2: Request Non-Existent Format**

**Manual Action Required:**

1.  Open content viewer
2.  In browser console, manually call:

fetch(/api/content/${contentId}/format-url?format=braille, {  
headers: { 'Authorization': Bearer ${localStorage.getItem('auth_token')} }  
})  
.then(r => r.json())  
.then(console.log)

**Expected Response**:  
{  
"error": "Format not available",  
"details": "..."  
}

**✅ PASS Criteria**: Graceful error message (not 500 server error)  
**❌ FAIL if**: Server crashes or returns 500 error

**Step 5.3: Access File Without Auth**

**Manual Action Required:**

1.  Open browser console
2.  Clear auth token: localStorage.removeItem('auth_token')
3.  Try accessing converted file directly:

fetch('/api/content/file/uploads/converted/\[contentId\]/transcript.txt')  
.then(r => console.log(r.status))

**Expected**: 401 Unauthorized or 403 Forbidden.

**✅ PASS Criteria**: Auth required for file access  
**❌ FAIL if**: File accessible without authentication

**Test Results Summary Template**

Copy this template and fill in after completing all tests:

**TEST RESULTS - \[Date/Time\]**

**Environment**:

- OS: Windows 11
- Node Version: \[version\]
- Browser: Chrome \[version\]

**Issue 1 - Dashboard Content Visibility**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Issue 2 - Physical File Creation**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Issue 3 - Format Serving (404 Errors)**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Formats tested: \[ \] Transcript \[ \] Simplified \[ \] Audio
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Issue 4 - Spotify-Style Audio Player**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Controls tested: \[ \] Play/Pause \[ \] Skip \[ \] Speed \[ \] Scrub
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Issue 5 - Progress Bar**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Issue 6 - Font Size Slider**:

- \[ \] ✅ PASS / \[ \] ❌ FAIL
- Notes: \___\___\___\___\___\___\___\___\___\___\___\___\___\___\__

**Overall Status**: \___ / 6 issues resolved

**Remaining Failures** (if any):

**Console Errors Observed**:  
\[Paste any error messages here\]

**Database Query Results**:  
\[Paste database output here\]

**Filesystem Check Results**:  
\[Paste ls/dir output here\]

**Failure Debugging Commands**

If tests fail, run these diagnostic commands:

**For Issue 1 Failures (Dashboard):**

**Check if courseOfferingId is being passed from frontend**

**Check browser Network tab → upload request payload**

**Should see: { file: ..., title: ..., courseOfferingId: "xxx" }**

**For Issue 2/3 Failures (File Creation):**

**Check server console for conversion errors**

**Look for: "\[Conversion\] Error creating directory" or similar**

**Manually verify conversion worker is running**

Get-Process | Where-Object {$\_.ProcessName -like "_node_"}

**Check if fs.promises is imported**

Select-String -Path "server\\lib\\conversionWorker.ts" -Pattern "fs.promises"

**For Issue 4 Failures (Audio Player):**

**Check if TTSAudioPlayer component was created**

Test-Path "client\\src\\components\\content\\TTSAudioPlayer.tsx"

**Check if it's imported in content-viewer**

Select-String -Path "client\\src\\pages\\content-viewer.tsx" -Pattern "TTSAudioPlayer"

**For Issue 5 Failures (Progress Bar):**

// In browser console, check progress calculation  
document.addEventListener('scroll', () => {  
const scrollTop = window.scrollY;  
const maxScroll = document.documentElement.scrollHeight - window.innerHeight;  
const progress = (scrollTop / maxScroll) \* 100;  
console.log(Progress: ${progress}%);  
});

**For Issue 6 Failures (Font Slider):**

// In browser console, check state binding  
// Find the slider element and log its value on change  
const slider = document.querySelector('input\[type="range"\]\[aria-label\*="text"\]');  
slider.addEventListener('input', (e) => {  
console.log('Slider value:', e.target.value);  
console.log('Applied fontSize:', getComputedStyle(document.querySelector('.prose')).fontSize);  
});

**Quick Pass/Fail Checklist**

**30-Second Smoke Test** (run this first to see if major issues fixed):

1.  \[ \] Upload file → appears on dashboard (Issue 1)
2.  \[ \] Click file → opens without 404 (Issue 3)
3.  \[ \] Switch to Audio → player appears (Issue 4)
4.  \[ \] Scroll content → progress bar fills (Issue 5)
5.  \[ \] Drag font slider → text resizes (Issue 6)

**If all 5 pass**: ✅ All core functionality working  
**If any fail**: Run full test suite above to identify specific failure point

**Next Steps After Testing**

**If all tests pass**:

1.  Mark all issues as resolved in bug tracker
2.  Commit changes with message: "Fix: Content upload pipeline, audio player, progress bar, font slider"
3.  Deploy to staging environment
4.  Run full Playwright test suite

**If tests fail**:

1.  Document exact failure point from this test script
2.  Paste failure output to Perplexity/Gemini for targeted fix
3.  Re-run tests after fix
4.  Repeat until all pass

**Automated Test Script Option**

**For Gemini CLI** - Save this as test-fixes.ps1:

**Automated test runner**

param(  
\[string\]$contentId = "PASTE_LATEST_CONTENT_ID"  
)

Write-Host "Testing AccessEd Fixes..." -ForegroundColor Green

**Test 1: Check converted folder**

if (Test-Path "uploads\\converted$contentId") {  
Write-Host "✅ Converted folder exists" -ForegroundColor Green  
} else {  
Write-Host "❌ Converted folder missing" -ForegroundColor Red  
}

**Test 2: Check files exist**

file in $files) {  
if (Test-Path "uploads\\converted$contentId$file") {  
$size = (Get-Item "uploads\\converted$contentId$file").Length  
Write-Host "✅ size bytes)" -ForegroundColor Green  
} else {  
Write-Host "❌ $file missing" -ForegroundColor Red  
}  
}

**Test 3: Verify file serving endpoint**

Write-Host "\`nManual tests required:" -ForegroundColor Yellow  
Write-Host "1. Check dashboard for new content"  
Write-Host "2. Open content viewer and test formats"  
Write-Host "3. Test audio player controls"  
Write-Host "4. Test progress bar (scroll content)"  
Write-Host "5. Test font size slider"

Run with: .\\test-fixes.ps1 -contentId "854e2e68-4f39-42f2-81dd-e4d14854d255"